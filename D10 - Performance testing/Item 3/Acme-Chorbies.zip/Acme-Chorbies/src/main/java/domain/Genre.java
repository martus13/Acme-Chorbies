
package domain;

public enum Genre {

	man, woman;
}
